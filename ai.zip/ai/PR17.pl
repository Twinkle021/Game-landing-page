
delete_nth(1, [_|T], T). % Base case: Deleting the first item of the list
delete_nth(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete_nth(N1, T, R).

read_list(L) :-
    write('Please enter the list (in square brackets): '),
    read(L).

read_position(N) :-
    write('Please enter the position of the item you want to delete: '),
    read(N).

delete_n :-
    read_list(L), % Read the list from the user
    read_position(N), % Read the position from the user
    ( delete_nth(N, L, R) -> write('The resulting list after deletion is: '),
     writeln(R); writeln('Invalid Position')
    ).
