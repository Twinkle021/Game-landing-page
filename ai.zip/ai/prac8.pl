memb(X,[X|_]).
memb(X,[_|TAIL]) :- memb(X,TAIL).

check_members:-
  write('Enter the list members: '),read(Y),
  write('Enter the number to be checked: '),read(X),
  memb(X,Y),
  format('Yes,~d is member of the list',[X]).


