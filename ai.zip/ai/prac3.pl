fact(0, 1).
fact(N, F) :-
    N > 0,
    N1 is N - 1,
    fact(N1, F1),
    F is N * F1.

factorial:-
    write('Enter the number to calculate the factorial: '),read(N),
    fact(N,F),
    format('The factorial of ~d is: ~d',[N,F]).
