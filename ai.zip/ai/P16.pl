insert_nth(Item, 1, List, [Item|List]).
insert_nth(Item, N, [Head|Tail], [Head|Result]) :-
    N > 1,
    N1 is N - 1,
    insert_nth(Item, N1, Tail, Result).

insert_n :-
    write('Enter an Element to insert: '),
    read(Item),
    write('Enter a List: '),
    read(List),
    write('Enter the position to insert: '),
    read(Position),
    insert_nth(Item, Position, List, Result),
    write('Resultant List is: '),
    write(Result).

