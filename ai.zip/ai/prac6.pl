power(_,0,1).
power(Num,Pow,Ans):- Ans is Num ^ Pow.

power_result:-
  write('Enter the Number: '),read(X),
  write('Enter the power : '),read(Y),
  power(X,Y,Z),
  write('Result : '),write(Z).
