sum:-
    write('Enter the first number: '), read(X),
    write('Enter the second number: '),read(Y),
    Sum is X+Y,
    write('Sum is '), write(Sum).
