%If N is 1 then it will return the First Element(Base Case).
nth_element(1,[X | _],X).

%Predicate to Find thenth Element
nth_element(N,[_ | L],X) :-
    N > 1,
    N1 is N-1,
    nth_element(N1,L,X).

pos_of_element :-
    write('Enter a List  : '),
    read(List),
    write('Enter the Position to Find Element : '),
    read(N),
    nth_element(N,List,Y),
    write(N),write(' Element of List is : '),
    write(Y).
