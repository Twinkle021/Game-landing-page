fibn(0, 0).
fibn(1, 1).
fibn(N, T) :-
    N > 1,
    N1 is N - 1,
    N2 is N - 2,
    fibn(N1, T1),
    fibn(N2, T2),
    T is T1 + T2.

generate_fib:-
    write('Enter the position of the fibonacci Series: '),read(X),
    fibn(X,Y),
    format('The ~dth term of fibonacci series is: ~d',[X,Y]).
