conc([], L, L).
conc([X|L1], L2, [X|L3]) :-
    conc(L1, L2, L3).

concat_list:-
    write("Enter the list L1 elements: "),read(X),
    write("Enter the list L2 elements: "),read(Y),
    conc(X, Y, Result),
    write("Concatenated List: "), write(Result).

