read_list(L) :-
    write('Enter a List to Check : '),
    read(L).

%Predicate to check if a list has Even Length
evenLength(L) :-
    length(L,Len),
    Len mod 2 =:= 0.

%Predicate to check if a list has odd Length
oddLength(L) :-
    length(L,Len),
    Len mod 2 =:= 1.

check_length_of_list :-
    read_list(L),
    (   evenLength(L) ->
    write('The List has a Even Length.');
    oddLength(L) ->
    write('The List has Odd Length.');
    write('Invalid')).
