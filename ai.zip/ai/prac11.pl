%To check wheather the Given Listis Palindrome or not.
palindrome(List):- listreverse(List,List).

%To Find the reverse of Entered List
listreverse([],[]).
listreverse([First|Rest],Reversed) :-
    listreverse(Rest,ReversedRest),
    concatenation(ReversedRest,[First],Reversed).

%To concatenate the List
concatenation([],L,L).
concatenation([X1|L1],L2,[X1|L3]) :-
    concatenation(L1,L2,L3).

check_palindrome :-
    write('Enter a List To Check Palindrome : '),
    read(List),
    (   palindrome(List) ->
    write('Entered List is a Palindrome.')
    ;   write('Entered List is Not a Palindrome.')
    ).

