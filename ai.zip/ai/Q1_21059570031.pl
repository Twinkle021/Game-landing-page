parent(pam,bob).
parent(tom,bob).
parent(tom,liz).
parent(bob,ann).
parent(bob,pat).
parent(pat,jim).
parent(ann,lily).

female(pam).
female(liz).
female(pat).
female(ann).
male(jim).
male(tom).
male(bob).

offspring(liz,tom) :- parent(tom,liz).
mother(X,Y) :- parent(X,Y),female(X).
grandparent(X,Z) :- parent(X,Y),parent(Y,Z).

different(X,Y) :- X \= Y.

sister(X,Y) :- parent(Z,X),parent(Z,Y),female(X),different(X,Y).


happy(X) :- parent(X,_).


hastwochildren(X) :-
    parent(X, Y),
    sister(_,Y).

grandchild(X,Y) :- parent(Z,X),parent(Y,Z).

aunt(X,Y) :- sister(X,Z),parent(Z,Y).


predecessor(X,Z) :- parent(X,Z).
predecessor(X,Z) :- parent(X,Y),predecessor(Y,Z).

maternalgrandmother(X,Y) :- mother(Z,Y),mother(X,Z).
father(X,Y) :- parent(X,Y),male(X).
maternalgrandfather(X,Y) :- mother(Z,Y),father(X,Z).
paternalgrandmother(X,Y) :- father(Z,Y),mother(X,Z).

paternalgrandfather(X,Y) :- father(Z,Y),father(X,Z).

siblings(X,Y) :- parent(Z,X),parent(Z,Y).


cousins(X,Y) :- grandparent(Z,X),grandparent(Z,Y),
    parent(K,X),parent(M,Y),different(K,M).

