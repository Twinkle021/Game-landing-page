multi(_,0,0).
multi(N1,N2,R):- R is N1 * N2.

multiplication:-
  write('Enter the first number to be multiplied: '),read(X),
  write('Enter the second number to be multiplied: '),read(Y),
  multi(X,Y,Z),
  write('Multiplication Result: '),write(Z).
