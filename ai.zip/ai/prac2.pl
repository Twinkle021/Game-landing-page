max(X,Y,X) :-
    X >= Y.
max(X,Y,Y) :- X < Y.

find_max:-
    write('Enter the first number: '),read(X),
    write('Enter the second number: '),read(Y),
    max(X,Y,M),format('The maximum of ~d and ~d is: ~d',[X,Y,M]).
