reverse([], []).
reverse([X|Xs], R) :-
    reverse(Xs, Rs),
    append(Rs, [X], R).
reverse_list:-
    write("Enter the list elements: "),read(X),
    reverse(X,Result),
    write("The reverse of the list is: ")],
    write(Result).
