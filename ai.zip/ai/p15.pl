max([R],R).
max([X|Xs],R):- max(Xs,T), (X > T ->R=X;R=T).

maximum:-
    write("Enter the elements of list: "),read(X),
    max(X,M),write("Maximum in the list is "),write(M).
