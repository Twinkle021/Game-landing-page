%Sum of an Empty List is Zero
listSum([],0).
%Predicate to Find Sum of Eelements of an List.
listSum([First|Rest],Sum) :-
    listSum(Rest,SumRest),
    Sum is SumRest + First.
%Predicate To Take User Input and Find Sum of Given List
find_SOL :-
    write('Enter a List To Find Sum : '),
    read(L),
    listSum(L,Sum), write('Sum of List '),
    write(L),write(' is : '),write(Sum).
