const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const port = 10001;

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: true }));

// Create a MySQL connection pool
const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  database: 'mysql',
  password:''
});

// Route to handle Sign In form submission
app.post('/signin', (req, res) => {
  const { username, password } = req.body;

  pool.query('SELECT * FROM user_data WHERE username = ? AND password = ?', [username, password], (err, result) => {
    if (err) {
      console.error('Error querying database:', err);
      res.status(500).send('Error querying database');
    } else {
      if (result.length > 0) {
        // User found, do something (e.g., redirect to a welcome page)
      //  res.status(200).send('Welcome, ' + username);
        res.sendFile(__dirname + '/welcome.html'); // Send the welcome page
      } else {
        // User not found or invalid credentials
        res.status(401).send('Invalid username or password');
      }
    }
  });
});

// Route to handle Sign Up form submission
app.post('/signup', (req, res) => {
  const { newUsername, newPassword } = req.body;

  pool.query('INSERT INTO user_data (username, password) VALUES (?, ?)', [newUsername, newPassword], (err, result) => {
    if (err) {
      console.error('Error inserting data:', err);
      res.status(500).send('Error inserting data');
    } else {
      console.log('1 record inserted');
     // res.redirect('/');
      res.setHeader('Content-Type', 'text/html');
      res.write('<script>alert("User signed up successfully");</script>');
      res.write('<script>window.location="/";</script>');
      res.end();
    }
  });
});

// Serve index.html file
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});
