# Import and load digits dataset
from sklearn.datasets import load_digits
digits = load_digits()
# Import matplotlib %matplotlib inline
import matplotlib.pyplot as plt
plt.gray()
for i in range(5):
    plt.matshow(digits.images[i])
